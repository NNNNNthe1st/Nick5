from django.shortcuts import render
from datetime import datetime, timedelta
from django.http import JsonResponse
from .models import ScheduledClass 

def index(request):
    # Generate lesson times
    lesson_times = []
    start_time = datetime.strptime("07:00", "%H:%M")
    end_time = datetime.strptime("22:00", "%H:%M")
    
    while start_time < end_time:
        lesson_times.append(start_time.strftime("%I:%M %p"))
        start_time += timedelta(minutes=50)  # 40 minutes lesson + 10 minutes interval

    courses = []  # Replace this with your course fetching logic
    context = {
        'lesson_times': lesson_times,
        'courses': courses,
    }
    return render(request, 'main/index.html', context)

  #Backend Booking logic for the booking added to the front end.
def book_lesson(request):
    if request.method == 'POST' and request.user.is_authenticated:
        course_id = request.POST.get('courseId')
        lesson_date = request.POST.get('lessonDate')

        # Logic to create a scheduled class
        scheduled_class = ScheduledClass.objects.create(
            student=request.user,
            course_id=course_id,
            date=lesson_date,
            # Add any other required fields
        )

        return JsonResponse({'success': True})

    return JsonResponse({'success': False}, status=400)




#Displaying sheduled classes for the student
def my_classes(request):
    if request.user.is_authenticated and hasattr(request.user, 'studentprofile'):
        # Get all scheduled classes for the authenticated student
        scheduled_classes = ScheduledClass.objects.filter(student=request.user)
        return render(request, 'main/my_classes.html', {'scheduled_classes': scheduled_classes})
    else:
        return render(request, 'main/my_classes.html', {'scheduled_classes': []})

#this is to allow a student to cancel  schedule. A student cant cancel a schedule within 24 hours. timezone is jst
from django.shortcuts import redirect, get_object_or_404
from django.utils import timezone
from django.utils.timezone import make_aware
from datetime import timedelta
from .models import Lesson

def cancel_lesson(request, lesson_id):
    if request.method == 'POST':
        lesson = get_object_or_404(Lesson, id=lesson_id, student=request.user)
        lesson_start_time = make_aware(datetime.combine(lesson.date, lesson.start_time))
        
        # Check if the lesson is within 24 hours
        if timezone.now() >= lesson_start_time - timedelta(hours=24):
            # You may want to handle this case with a message to the user
            return redirect('student_dashboard')  # Redirect or show a message

        lesson.is_cancelled = True
        lesson.save()
        return redirect('student_dashboard')  # Redirect after cancellation

#Make sure the main view's code has the following code for the students view
def student_dashboard(request):
    completed_lessons = Lesson.objects.filter(student=request.user, is_completed=True).order_by('-date', '-start_time')
    remaining_lessons = Lesson.objects.filter(student=request.user, is_completed=False).order_by('date', 'start_time')
    comments = Comment.objects.filter(student=request.user, approved=True)

    return render(request, 'student_dashboard.html', {
        'completed_lessons': completed_lessons,
        'remaining_lessons': remaining_lessons,
        'comments': comments,
    })


#submitting ratings
from django.shortcuts import render, redirect, get_object_or_404
from .models import Lesson, Rating
from .forms import RatingForm

def rate_lesson(request, lesson_id):
    lesson = get_object_or_404(Lesson, id=lesson_id, student=request.user)
    
    if request.method == 'POST':
        form = RatingForm(request.POST)
        if form.is_valid():
            rating = form.save(commit=False)
            rating.lesson = lesson
            rating.student = request.user
            rating.save()
            return redirect('student_dashboard')  # Redirect after saving
    else:
        form = RatingForm()
    
    return render(request, 'rate_lesson.html', {'form': form, 'lesson': lesson})


#Display Approved Comments on the Homepage
from .models import Rating

def home(request):
    approved_ratings = Rating.objects.filter(approved=True).order_by('-created_at')[:5]  # Fetch the latest 5 approved ratings
    return render(request, 'index.html', {'approved_ratings': approved_ratings})


#views for course creation
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Course, CourseMaterial

def create_course(request):
    if request.method == 'POST':
        title = request.POST.get('course_title')
        description = request.POST.get('course_description')
        course_type = request.POST.get('course_type')
        lessons_count = request.POST.get('lessons_count')
        price = request.POST.get('course_price')
        materials = request.FILES.getlist('materials')  # Get list of uploaded files

        # Create the course
        new_course = Course(
            title=title,
            description=description,
            course_type=course_type,
            lessons_count=lessons_count,
            price=price
        )
        new_course.save()  # Save the course instance

        # Save course materials
        for material in materials:
            CourseMaterial.objects.create(course=new_course, material_file=material)

        messages.success(request, 'Course created successfully!')
        return redirect('admin_dashboard')  # Redirect to admin dashboard or relevant page

    return render(request, 'admin_dashboard.html')  # Render the dashboard template for GET request
